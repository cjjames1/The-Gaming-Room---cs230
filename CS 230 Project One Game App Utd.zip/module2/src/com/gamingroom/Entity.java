package com.gamingroom;

public class Entity {
	// Protected variables for id and name
	protected long id;
	protected String name;

	// Protected default constructor 
	protected Entity() {}
		
	// Public constructor with id and name
	public Entity(long id, String name) {
			this.id = id;
			this.name = name;
	}

	// Method to access id
	public long getId() {
		return id;
	}
		
	// Method to access name
	public String getName() {
		return name;
	}
		
	@Override
	public String toString() {
		return "Entity [id=" + id + ", name=" + name + "]";
	}
}

