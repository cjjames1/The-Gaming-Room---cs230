package com.gamingroom;

import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;
import java.util.Iterator;
/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu
 */
public class GameService {

	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();

	/*
	 * Holds the next game identifier
	 */
	private static long nextGameId = 1;

	private static long nextPlayerId = 1;
	
	private static long nextTeamId = 1;
	
	// An object of GameService
	private static GameService service = new GameService();
	
	// Constructor made private so that the class
	// cannot be instantiated 
	private GameService() {};
	
	// Getter function for GameService using singleton design pattern
	public static GameService getGameService() {
		
		// Only adds the new instance service if null
		// Else returns the single instance
		// This way only one instance is instantiated
		if (service == null) {
			
			service = new GameService();	
		}
		else {
			// No output. Print 'error'.
		}
		
		
		return service;
	}
	
	/**
	 * Checks if an existing GameService instance exists.
	 * If not, it makes one then returns the instance.
	 * 
	 * @return the gameservice instance
	 */
	
	public static GameService getInstance() {
		if (service == null) {
			service = new GameService();
		}
		return service;
	}
	/**
	 * Construct a new game instance
	 * 
	 * @param name the unique name of the game
	 * @return the game instance (new or existing)
	 */
	public Game addGame(String name) {

		// A local game instance
		Game game = null;

		// getGame(name) iterates over games and if the name entered is found, 
		// it is returned.
		if (getGame(name) != null) {
		
				getGame(name);  
		}	
		// If not found, name is turned to a new game instance and is added to list of games
		else {
				game = new Game(nextGameId++, name);
				games.add(game);
			}

		// Return the new/existing game instance to the caller
		return game;
	}
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {

		// A local game instance
		Game game = null;

		// A local iterator variable currGame loops
		// in the for loop through the games list.
		// If id entered matches, id is returned.
		for (Game currGame:games) {
		
			if (currGame.getId() == id) {
		
					game = currGame;
					break;
			}
		}
		
		return game;
	}

	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// A local game instance
		Game game = null;

		// A local variable currentGame is created in the for loop
		// which loops through the games list.
		// If currentGame matches name, it is set equal to game and returned.
		for (Game currGame:games) {
			
			if (currGame.getName().equalsIgnoreCase(name)) {
				
				game = currGame;
				break;
				
			}
	}
		
		return game;
	}

	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	}
	
	// Returns next Player id, used in iteration
	public long getNextPlayerId() {
		return nextPlayerId++;
	}
	
	// Returns next Team id, used in iteration
	public long getNextTeamId() {
		return nextTeamId++;
	}
}
